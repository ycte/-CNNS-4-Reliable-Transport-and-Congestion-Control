//package TCPSock;

import java.lang.reflect.Method;
import java.util.LinkedList;

public class TCPSock {
    private TCPManager tcpMan = null;
    private TCPSockID id = new TCPSockID();
    private State state;
    private int snd_MSS;
    private int snd_initseq;
    private int rcv_initseq;
    private LinkedList<TCPSock> pendingConnections;
    private int backlog;
    private byte[] snd_buf;
    private int snd_base;
    private int snd_top;
    private int snd_next;
    private byte[] rcv_buf;
    private int rcv_base;
    private int rcv_top;
    private int rcv_next;
    private long RTO;
    private int rt_seq;
    private int rt_pending;
    private int rt_expired;
    private int dup_ack;
    private int fast_ret;
    private long RTT_estimate;
    private long RTTDev_estimate;
    private int RTT_sample_seq;
    private long RTT_sample_send_time;
    private int snd_rcvWnd;
    private float snd_cwnd;
    private float snd_ssthresh;
    private int snd_wnd;

    public TCPSock() {
        this.state = TCPSock.State.NEW;
        this.snd_MSS = 107;
        this.snd_initseq = 0;
        this.rcv_initseq = 0;
        this.pendingConnections = null;
        this.backlog = 0;
        this.snd_buf = null;
        this.snd_base = 0;
        this.snd_top = 0;
        this.snd_next = 0;
        this.rcv_buf = null;
        this.rcv_base = 0;
        this.rcv_top = 0;
        this.rcv_next = 0;
        this.RTO = 1000L;
        this.rt_seq = 0;
        this.rt_pending = 0;
        this.rt_expired = 0;
        this.dup_ack = 0;
        this.fast_ret = 0;
        this.RTT_estimate = this.RTO;
        this.RTTDev_estimate = 0L;
        this.RTT_sample_seq = -1;
        this.RTT_sample_send_time = 0L;
        this.snd_rcvWnd = 0;
        this.snd_cwnd = 1.0F;
        this.snd_ssthresh = 16384.0F;
        this.update_snd_wnd();
    }

    public TCPManager getManager() {
        return this.tcpMan;
    }

    public void setManager(TCPManager tcpMan) {
        this.tcpMan = tcpMan;
    }

    public TCPSockID getID() {
        return this.id;
    }

    public void setID(TCPSockID id) {
        this.id = id;
    }

    public State getState() {
        return this.state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public int bind(int localPort) {
        if (this.id.getLocalPort() != 256) {
            return -1;
        } else if (localPort == 256) {
            return -1;
        } else {
            int localAddr = this.id.getLocalAddr();
            TCPSock sock = this.tcpMan.getLocalSock(localAddr, localPort);
            if (sock != null) {
                return -1;
            } else {
                this.id.setLocalPort(localPort);
                return 0;
            }
        }
    }

    public int listen(int backlog) {
        if (this.state != TCPSock.State.NEW) {
            return -1;
        } else if (this.id.getLocalPort() == 256) {
            return -1;
        } else {
            this.pendingConnections = new LinkedList();
            this.backlog = backlog;
            this.state = TCPSock.State.LISTEN;
            return 0;
        }
    }

    public TCPSock accept() {
        if (this.state != TCPSock.State.LISTEN) {
            return null;
        } else {
            return this.pendingConnections.isEmpty() ? null : (TCPSock)this.pendingConnections.removeFirst();
        }
    }

    public boolean isConnectionPending() {
        return this.state == TCPSock.State.SYN_SENT;
    }

    public boolean isClosed() {
        return this.state == TCPSock.State.CLOSED;
    }

    public boolean isConnected() {
        return this.state == TCPSock.State.ESTABLISHED;
    }

    public boolean isClosurePending() {
        return this.state == TCPSock.State.SHUTDOWN;
    }

    public int connect(int destAddr, int destPort) {
        if (this.state != TCPSock.State.NEW) {
            return -1;
        } else if (this.id.getLocalPort() == 256) {
            return -1;
        } else {
            this.id.setRemoteAddr(destAddr);
            this.id.setRemotePort(destPort);
            this.snd_buf = new byte[16385];
            this.snd_initseq = this.snd_base = this.snd_top = this.snd_next = this.tcpMan.initSeq(this);
            this.RTT_sample_seq = this.snd_base - 1;
            ++this.snd_top;
            this.state = TCPSock.State.SYN_SENT;
            this.sendSYN();
            return 0;
        }
    }

    public void close() {
        if (this.state != TCPSock.State.LISTEN) {
            if (this.state == TCPSock.State.ESTABLISHED) {
                if (this.snd_base == this.snd_next) {
                    this.tcpMan.send(this.id, 2, 0, this.snd_base, this.snd_buf, 0);
                    this.state = TCPSock.State.CLOSED;
                } else {
                    this.state = TCPSock.State.SHUTDOWN;
                }
            } else if (this.state != TCPSock.State.SHUTDOWN) {
                this.state = TCPSock.State.CLOSED;
            }
        } else {
            while(true) {
                if (this.pendingConnections.isEmpty()) {
                    this.state = TCPSock.State.CLOSED;
                    break;
                }

                TCPSock conn = (TCPSock)this.pendingConnections.removeFirst();
                this.tcpMan.release(conn);
            }
        }

    }

    public void release() {
        this.close();
        if (this.state == TCPSock.State.SHUTDOWN) {
            this.tcpMan.send(this.id, 2, 0, this.snd_base, this.snd_buf, 0);
        }
        this.tcpMan.release(this);
    }

    public int write(byte[] buf, int pos, int len) {
        if (this.state == TCPSock.State.CLOSED) {
            return -1;
        } else if (this.state != TCPSock.State.ESTABLISHED) {
            return -1;
        } else if (this.snd_buf == null) {
            return -1;
        } else {
            int avail = this.snd_buf.length - 1 - (this.snd_next - this.snd_base);
            int cnt = Math.min(avail, len);
            if (cnt == 0) {
                return 0;
            } else {
                qwrite(this.snd_buf, this.snd_next, buf, pos, cnt);
                int seq = this.snd_next;

                for(this.snd_next += cnt; seq < this.snd_base + this.snd_wnd && seq < this.snd_next; seq += this.sendDATA(seq)) {
                }

                return cnt;
            }
        }
    }

    public int read(byte[] buf, int pos, int len) {
        if (this.state == TCPSock.State.CLOSED) {
            return -1;
        } else if (this.state != TCPSock.State.ESTABLISHED && this.state != TCPSock.State.SHUTDOWN) {
            return -1;
        } else if (this.rcv_buf == null) {
            return -1;
        } else {
            int avail = this.rcv_base - this.rcv_next;
            int cnt = Math.min(avail, len);
            if (cnt == 0) {
                return 0;
            } else {
                qread(this.rcv_buf, this.rcv_next, buf, pos, cnt);
                this.rcv_next += cnt;
                this.rcv_top += cnt;
                if (this.state == TCPSock.State.SHUTDOWN && this.rcv_next == this.rcv_base) {
                    this.state = TCPSock.State.CLOSED;
                }

                return cnt;
            }
        }
    }

    public void OnReceive(int srcAddr, int destAddr, Transport segment) {
        switch (segment.getType()) {
            case 0:
                this.receiveSYN(srcAddr, destAddr, segment);
                break;
            case 1:
                this.receiveACK(srcAddr, destAddr, segment);
                break;
            case 2:
                this.receiveFIN(srcAddr, destAddr, segment);
                break;
            case 3:
                this.receiveDATA(srcAddr, destAddr, segment);
        }

    }

    private void receiveSYN(int srcAddr, int destAddr, Transport syn) {
        System.out.print("S");
        if (this.state == TCPSock.State.LISTEN) {
            TCPSock conn = null;
            TCPSockID sid = new TCPSockID();
            sid.setLocalAddr(this.id.getLocalAddr());
            sid.setLocalPort(this.id.getLocalPort());
            sid.setRemoteAddr(srcAddr);
            sid.setRemotePort(syn.getSrcPort());
            int ackNum = syn.getSeqNum() + 1;
            if (this.pendingConnections.size() >= this.backlog || (conn = this.tcpMan.socket()) == null) {
                this.tcpMan.send(sid, 2, 0, ackNum, (byte[])null, 0);
                return;
            }

            conn.setID(sid);
            conn.rcv_buf = new byte[16385];
            conn.rcv_base = conn.rcv_next = ackNum;
            conn.rcv_top = conn.rcv_base + 16384;
            conn.rcv_initseq = ackNum - 1;
            int rcv_wnd = conn.rcv_top - conn.rcv_base;
            this.tcpMan.send(sid, 1, rcv_wnd, conn.rcv_base, (byte[])null, 0);
            conn.setState(TCPSock.State.ESTABLISHED);
            this.pendingConnections.addLast(conn);
        } else if (this.state == TCPSock.State.ESTABLISHED && syn.getSeqNum() == this.rcv_initseq) {
            int rcv_wnd = this.rcv_top - this.rcv_base;
            this.tcpMan.send(this.id, 1, rcv_wnd, this.rcv_base, (byte[])null, 0);
        }

    }

    private void receiveFIN(int srcAddr, int destAddr, Transport fin) {
        System.out.print("F");
        if (this.state == TCPSock.State.ESTABLISHED) {
            if (this.rcv_next == this.rcv_base) {
                this.state = TCPSock.State.CLOSED;
            } else {
                this.state = TCPSock.State.SHUTDOWN;
            }
        }

    }

    private void receiveACK(int srcAddr, int destAddr, Transport ack) {
        int ackNum = ack.getSeqNum();
        if (this.state == TCPSock.State.SYN_SENT && ackNum == this.snd_base + 1) {
            System.out.print(":");
            this.state = TCPSock.State.ESTABLISHED;
            this.snd_base = ackNum;
            this.snd_next = ackNum;
            this.snd_rcvWnd = ack.getWindow();
            this.update_snd_wnd();
        } else if (this.state != TCPSock.State.ESTABLISHED && this.state != TCPSock.State.SHUTDOWN) {
            System.out.print("?");
        } else if (ackNum > this.snd_top) {
            System.out.print("?");
        } else {
            this.snd_rcvWnd = ack.getWindow();
            this.update_snd_wnd();
            int next_to_send;
            if (ackNum > this.snd_base) {
                System.out.print(":");
                this.rt_pending = 0;
                this.rt_expired = 0;
                this.dup_ack = 0;
                this.fast_ret = 0;
                if (this.RTT_sample_seq >= this.snd_base && ackNum > this.RTT_sample_seq) {
                    long RTT_sample = this.tcpMan.now() - this.RTT_sample_send_time;
                    this.RTT_estimate = (long)((double)this.RTT_estimate * 0.875);
                    this.RTT_estimate = (long)((double)this.RTT_estimate + (double)RTT_sample * 0.125);
                    this.RTTDev_estimate = (long)((double)this.RTTDev_estimate * 0.75);
                    this.RTTDev_estimate = (long)((double)this.RTTDev_estimate + (double)Math.abs(this.RTT_estimate - RTT_sample) * 0.25);
                    this.RTO = this.RTT_estimate + 4L * this.RTTDev_estimate;
                    this.RTO = Math.max(this.RTO, 50L);
                    this.RTO = Math.min(this.RTO, 30000L);
                }

                next_to_send = Math.min(this.snd_base + this.snd_wnd, this.snd_top);
                int seq;
                if (this.snd_cwnd < this.snd_ssthresh) {
                    seq = (ackNum - this.snd_base + this.snd_MSS - 1) / this.snd_MSS;
                    this.snd_cwnd += (float)seq;
                } else {
                    this.snd_cwnd += 1.0F / this.snd_cwnd;
                }

                this.update_snd_wnd();
                this.snd_base = ackNum;
                if (this.snd_base < this.snd_next) {
                    if (this.snd_base < this.snd_top) {
                        this.start_rt_timer(this.snd_base);
                    }

                    for(seq = Math.max(next_to_send, this.snd_base); seq < this.snd_base + this.snd_wnd && seq < this.snd_next; seq += this.sendDATA(seq)) {
                    }
                } else if (this.state == TCPSock.State.SHUTDOWN) {
                    this.tcpMan.send(this.id, 2, 0, this.snd_base, this.snd_buf, 0);
                    this.state = TCPSock.State.CLOSED;
                }

            } else {
                System.out.print("?");
                ++this.dup_ack;
                if (this.dup_ack == 3) {
                    this.RTT_sample_seq = this.snd_base - 1;
                    this.snd_cwnd = this.snd_ssthresh = Math.max(this.snd_cwnd / 2.0F, 1.0F);
                    this.update_snd_wnd();
                    if (this.fast_ret < 1) {
                        for(next_to_send = this.snd_base; next_to_send < this.snd_base + this.snd_wnd && next_to_send < this.snd_next; next_to_send += this.sendDATA(next_to_send)) {
                        }

                        ++this.fast_ret;
                    }
                }

            }
        }
    }

    private void receiveDATA(int srcAddr, int destAddr, Transport data) {
        int seqNum = data.getSeqNum();
        if (seqNum == this.rcv_base) {
            System.out.print(".");
            byte[] payload = data.getPayload();
            int len = payload.length;
            int avail = this.rcv_top - this.rcv_base;
            int cnt = Math.min(avail, len);
            qwrite(this.rcv_buf, this.rcv_base, payload, 0, cnt);
            this.rcv_base += cnt;
        } else {
            System.out.print(".");
        }

        int rcv_wnd = this.rcv_top - this.rcv_base;
        this.tcpMan.send(this.id, 1, rcv_wnd, this.rcv_base, (byte[])null, 0);
    }

    public static void qread(byte[] src, int srcPos, byte[] dest, int destPos, int len) {
        srcPos %= src.length;
        if (srcPos + len > src.length) {
            int cnt = src.length - srcPos;
            System.arraycopy(src, srcPos, dest, destPos, cnt);
            destPos += cnt;
            System.arraycopy(src, 0, dest, destPos, len - cnt);
        } else {
            System.arraycopy(src, srcPos, dest, destPos, len);
        }

    }

    public static void qwrite(byte[] dest, int destPos, byte[] src, int srcPos, int len) {
        destPos %= dest.length;
        if (destPos + len > dest.length) {
            int cnt = dest.length - destPos;
            System.arraycopy(src, srcPos, dest, destPos, cnt);
            srcPos += cnt;
            System.arraycopy(src, srcPos, dest, 0, len - cnt);
        } else {
            System.arraycopy(src, srcPos, dest, destPos, len);
        }

    }

    public void sendSYN() {
        if (this.state == TCPSock.State.SYN_SENT) {
            this.tcpMan.send(this.id, 0, 0, this.snd_base, this.snd_buf, 0);
            System.out.print("S");
            try {
                Method method = Callback.getMethod("sendSYN", this, (String[])null);
                Callback cb = new Callback(method, this, (Object[])null);
                this.tcpMan.addTimer(1000L, cb);
            } catch (Exception var3) {
                var3.printStackTrace();
                System.exit(1);
            }

        }
    }

    private void update_snd_wnd() {
        int rwnd = Math.max(this.snd_rcvWnd, 1);
        int cwnd = Math.round(this.snd_cwnd) * this.snd_MSS;
        this.snd_wnd = Math.min(rwnd, cwnd);
    }

    private int sendDATA(int seq) {
        int unsent = this.snd_next - seq;
        int inWnd = this.snd_base + this.snd_wnd - seq;
        int cnt = Math.min(unsent, inWnd);
        cnt = Math.min(cnt, this.snd_MSS);
        this.tcpMan.send(this.id, 3, 0, seq, this.snd_buf, cnt);
        int top = seq + cnt;
        if (this.snd_top < top) {
            this.snd_top = top;
        }

        if (seq == this.snd_base) {
            this.start_rt_timer(seq);
        }

        if (this.RTT_sample_seq < this.snd_base) {
            this.RTT_sample_seq = seq;
            this.RTT_sample_send_time = this.tcpMan.now();
        }
        System.out.print(".");
        return cnt;
    }

    private void start_rt_timer(int seq) {
        try {
            String[] paramTypes = new String[]{"java.lang.Integer"};
            Object[] params = new Object[]{seq};
            Method method = Callback.getMethod("retransmit", this, paramTypes);
            Callback cb = new Callback(method, this, params);
            this.tcpMan.addTimer(this.RTO, cb);
            ++this.rt_pending;
        } catch (Exception var6) {
            var6.printStackTrace();
            System.exit(1);
        }

    }

    public void retransmit(Integer seqNum) {
        int seq = seqNum;
        if (this.snd_base <= seq) {
            if (this.rt_pending-- <= 1) {
                ++this.rt_expired;
                this.dup_ack = 0;
                this.fast_ret = 0;
                this.RTT_sample_seq = this.snd_base - 1;
                this.snd_ssthresh = Math.max(this.snd_cwnd / 2.0F, 1.0F);
                this.snd_cwnd = 1.0F;
                this.update_snd_wnd();
                if (this.rt_expired == 1) {
                    this.RTO *= 2L;
                    this.RTO = Math.min(this.RTO, 30000L);
                    this.rt_expired = 0;
                }

                System.out.print("!");

                while(seq < this.snd_base + this.snd_wnd && seq < this.snd_next) {
                    seq += this.sendDATA(seq);
                }

            }
        }
    }

    static enum State {
        CLOSED,
        LISTEN,
        SYN_SENT,
        ESTABLISHED,
        NEW,
        SHUTDOWN,
        ANY;

        private State() {
        }
    }
}
