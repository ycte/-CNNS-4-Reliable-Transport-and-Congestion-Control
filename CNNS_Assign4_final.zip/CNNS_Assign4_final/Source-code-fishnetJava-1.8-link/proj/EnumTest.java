public class EnumTest {
    static enum State {
        CLOSED,
        LISTEN,
        SYN_SENT,
        ESTABLISHED,
        NEW,
        SHUTDOWN,
        ANY;

        private State() {
        }
    }
}
