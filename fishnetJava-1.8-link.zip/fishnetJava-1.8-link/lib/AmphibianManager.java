public class AmphibianManager {
    private Node node;

    public AmphibianManager() {
	
    }
    
    public void setNode(Node node) {
	this.node = node;
    }
}
